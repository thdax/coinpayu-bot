from selenium import webdriver
from selenium.webdriver.common.by import By
import certifi
import time
import pyautogui


# LINKS
url = "https://www.coinpayu.com/dashboard/ads_surf"
# ACCOUNT SETTINGS

driver = webdriver.Firefox()
def login_bot():
    i = 0
    global url
    driver.get(url)
    input(' If you are logged in, press enter :')
    ads_count_check = driver.find_element(By.XPATH,'/html/body/div[1]/div/div[2]/div[2]/div/div/h6/span')
    print('Frameless Ads ' + ads_count_check.text)
                                        
    for i in range(1,46):
        check_time = driver.find_element(By.XPATH,f'/html/body/div[1]/div/div[2]/div[2]/div/div/div[2]/div[2]/div[{i}]/div/div[1]/div[2]/div[1]/p[2]/span')
        print('Wait Time ' + check_time.text)
        count_time = int(check_time.text)
        count_time += 6
        coin_check = driver.find_element(By.XPATH,f'/html/body/div[1]/div/div[2]/div[2]/div/div/div[2]/div[2]/div[{i}]/div/div[1]/div[2]/div[1]/p[1]/span')
        print("Coin : " + coin_check.text)

        ads_for_loop = driver.find_element(By.XPATH,f'/html/body/div[1]/div/div[2]/div[2]/div/div/div[2]/div[2]/div[{i}]/div/div[1]/div[1]/span').click()

        time.sleep(count_time)
        pyautogui.hotkey("ctrl", "w")
        time.sleep(4)
        

login_bot()